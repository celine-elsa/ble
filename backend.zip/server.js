const express = require("express");
const cors = require("cors");

const app = express();
const PORT = 3000;

// Allow Flutter requests
app.use(cors());
app.use(express.json());

// Store received data (TEMP, for testing)
const receivedData = [];
const devices = [];

const admin = require("firebase-admin");
const serviceAccount = require("./serviceAccountKey.json");

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
});


// POST endpoint (Flutter sends here)
app.post("/attendance", (req, res) => {
  console.log("📥 RECEIVED DATA:");
  console.log(req.body);

  receivedData.push({
    time: new Date().toISOString(),
    payload: req.body,
  });

  res.json({ status: "ok" });
});

app.post("/register-device", (req, res) => {
  console.log("📱 DEVICE REGISTER:");
  console.log(req.body);

  devices.push(req.body);

  res.json({ success: true });
});

// GET endpoint (view in browser)
app.get("/attendance", (req, res) => {
  res.json(receivedData);
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`🚀 Server running on http://0.0.0.0:${PORT}`);
});

async function sendNotification(token) {
  const message = {
    notification: {
      title: "Attendance Check",
      body: "Please confirm your presence",
    },
    token: token,
  };

  try {
    const response = await admin.messaging().send(message);
    console.log("✅ SENT:", response);
    return true;
  } catch (err) {
    console.error("❌ ERROR:", err);
    return false;
  }
}

app.get("/send-test", async (req, res) => {
  if (devices.length === 0) {
    return res.json({ error: "No devices registered" });
  }

  const token = devices[0].fcm_token;

  const ok = await sendNotification(token);

  res.json({ success: ok });
});